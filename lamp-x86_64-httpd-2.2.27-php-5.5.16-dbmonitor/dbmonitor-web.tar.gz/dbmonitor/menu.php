<?
header("Cache-Control: no-cache, must-revalidate");
include("sys_config.php"); 
$link_id=mysql_connect($db_ip,$db_user,$db_pas);

mysql_select_db("newdb");
$str="select * from web order by wid";
$back=mysql_query($str,$link_id);
mysql_close($link_id);
$kk1=mysql_num_rows($back);
for ($i=0;$i<$kk1;$i++){
   $webgo[$i]=mysql_fetch_array($back);
   $menustr=$menustr.$webgo[$i][1]."@".$webgo[$i][0]."~";
};
echo $menustr;
?>
