<?
header("Cache-Control: no-cache, must-revalidate");
include("sys_config.php");       //載入組態檔
include("phplib.php");
$dbsel=$_GET["dbselect"];//讀取使用者選擇
//if (!$dbsel){echo "error!!";}
switch ($dbsel) //判斷使用者選項，並產生sql語法
{
	case "all":
		$str="select wname,dbname,dbip,dbtype,dbport from web,dbwhere where web.wid=dbwhere.wid order by dbwhere.id2;";
		break;
	case "TP":
        	$str="select wname,dbname,dbip,dbtype,dbport from web,dbwhere where web.wid=dbwhere.wid order by dbwhere.id2 ;";
        break;
	case "TCbak":
		$str="select wname,dbname,dbip,dbtype,dbport from web,dbwhere where web.wid=dbwhere.wid and dbwhere.dbtype!='s' order by dbwhere.id2;";
		break;
	default:
		$str="select wname,dbname,dbip,dbtype,dbport from web,dbwhere where web.wid=dbwhere.wid and dbwhere.wid='$dbsel' order by dbwhere.id2;";
//		$str="select wname,dbip,dbtype,dbport from web,dbwhere where web.wid=dbwhere.wid order by dbwhere.id2;";
}
$aa=gomysql($db_ip,$db_user,$db_pas,"newdb",$str);
$dbnum=mysql_num_rows($aa);  //計算資料筆數
$bknumf=mysql_num_fields($aa);  //計算欄位數
for ($i=0;$i<$dbnum;$i++){
	$webshow[$i]=mysql_fetch_array($aa);};  //將結果存入陣列

for ($i=0;$i<$dbnum;$i++) //前往被監控端取值
{
	for ($k=0;$k<$bknumf;$k++)
	{
		echo $webshow[$i][$k].",";
	}	
	if($webshow[$i][3]=='m')//判斷是master or slave
	  {$str='show master status;';}
	else
	  {$str='show slave status;';}  
	  
	$dbp=":".$webshow[$i][4]; //指定連結port
//	$db_id=mysql_connect($webshow[$i][1].$dbp,$go_user,$go_pas);
	$ckdb=gomysql($webshow[$i][2].$dbp,$go_user,$go_pas,'',$str);
	if ($ckdb[0][0]!="error")
	{
		for($j=0;$j<$dbnum;$j++) //將結果存入陣列
		{
			$cktmp[$j]=mysql_fetch_array($ckdb);
		}
		$cknum=mysql_num_fields($ckdb);
		if($webshow[$i][3]=='m')
		{
			for ($l=0;$l<$cknum;$l++)
			{
				echo $cktmp[0][$l].",";
			}
		}
		else
		{
			echo $cktmp[0][9].","; //log name
			echo $cktmp[0][21].","; //sql run
			echo $cktmp[0][11].","; //log pos
			echo $cktmp[0][32].","; //sbm
		}
	}
	else
	{
		echo "e,";
	}

	echo "#";	
}
	

//for ($i=0;$i<$dbnum;$i++){
//	for ($k=0;$k<$bknumf;$k++)
//	{
//		echo $webshow[$i][$k].",";
//	}	

//	echo "#";
//}
?>







