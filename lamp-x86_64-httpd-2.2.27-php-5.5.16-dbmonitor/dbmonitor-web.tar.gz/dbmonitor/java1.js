function makeRequest(url,type){
	http_request = false;
	if (window.XMLHttpRequest) { // Mozilla, Safari,...
		http_request = new XMLHttpRequest();
		if (http_request.overrideMimeType) {
			http_request.overrideMimeType('text/xml');
		}
	}else if (window.ActiveXObject) { // IE
		try {
			http_request = new ActiveXObject("Msxml2.XMLHTTP");
		}catch (e) {
			try {
				http_request = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {}
		}
	}
	if (!http_request) {
		alert('Cannot create XMLHTTP instance');
		return false;
	}

	http_request.onreadystatechange = getHello;
	http_request.open('GET', url , true);
	http_request.send(null);
}

function getHello(){
	if (http_request.readyState == 4) {
		if (http_request.status == 200) {			
			var helloStr=http_request.responseText;
			
			document.getElementById("fishtest").innerHTML=helloStr;
			showchk(helloStr);
			
			var menutemp=helloStr.split("~");
			for (i=0;i<menutemp.length-1;i++){
				var menutemp2=menutemp[i].split("@");
				document.getElementById("fish").options[document.getElementById("fish").options.length]=new Option(menutemp2[1],menutemp2[0]);
			}
			document.getElementById("cd").innerHTML="更新完成!";
		}else{			
			document.getElementById("cd").innerHTML="更新失敗...";
			document.aaa.Play();
		}
	}
}

function go_back(){
	chk--;
	document.getElementById("cdt").innerHTML=chk;
	if (chk <= 0) {
		document.getElementById("cd").innerHTML="更新中...";
		makeRequest("showdb.php"+"?dbselect="+escape(document.forms[0].dbselect.value),"a");
		chk=document.getElementById("timesel").options.value;		
		chk=chk_time;
	}
	setTimeout("go_back()",1000);
}

function showchk(chkstr){
	document.getElementById("fishtest").innerHTML='';
	var ttmp=''; 
	var wor=false;//警告音效
	ttmp='<table border="1"><thead><tr bgcolor="#00FF00"><td>所屬</td><td>Nane</td><td>DB-IP</td><td>類別</td><td>log檔名稱</td><td>主從進度</td><td>差距</td><td>SBM</td><td>狀態</td></tr></thead><tbody>';
	var chk1=chkstr.split("#");

	for(i=0;i<chk1.length-1;i++){
		var err=0; //err 0=>正常 1=>pos值不正確 2=>binlog檔不正確 3=>主從標記為停止中 4=>無法連線
		var chkpos=0; //暫存master的pos值
		var chklog=false; //暫存master的binlog檔名
		var ste="ok"; //用來顯示資料庫狀態
		var chk2=chk1[i].split(","); //從字串中提取相關資訊存入陣列
		var bgc="<tr bgcolor=\"#ffffff\">"; //表格背景色預設值
		var ebgc="<tr bgcolor=\"#ff0000\">"; //錯誤背景色
		if (chk2[4]=="e") //檢查資料庫是否正常連線
		{chk2[4]="&nbsp";err=4;}
		switch(chk2[3]){//檢查資料庫類型
			case "m": //master
				var cktmp=chk2[6];
				var cklogtmp=chk2[5];
				bgc="<tr bgcolor=\"#00aaaa\">";
				chk2[3]="<a href=\"masinfo.php?mweb="+chk2[0]+"&mip="+chk2[2]+":"+chk2[4]+"\" target=\"_blank\">Master</a>";
			break;
			case "s": //slave
				chkpos=cktmp-chk2[6];
				if(chk2[5]!=cklogtmp){chklog=true;}
				if(chk2[7]!="Yes" && err==0){err=3}
				chk2[3]="<a href=\"masinfo.php?mweb="+chk2[0]+"&mip="+chk2[2]+":"+chk2[4]+"\" target=\"_blank\">Slave</a>";
			break;
			case "b": //backup(備份用)
				chkpos=cktmp-chk2[6];
				if(chk2[5]!=cklogtmp){chklog=true;}
				if(chk2[7]!="Yes" && err==0){err=3}
				bgc="<tr bgcolor=\"#00ffff\">";
				chk2[3]="<a href=\"masinfo.php?mweb="+chk2[0]+"&mip="+chk2[2]+":"+chk2[4]+"\" target=\"_blank\">backup</a>";
			break;
		}

		if(chkpos!=0 && err==0 && document.getElementById("worerr").options.value!="nochk" && chkpos>document.getElementById("worerr").options.value)
		{err=1;}//判斷資料庫pos值是否超過警告值
		

		if(chklog && err==0) //判斷log檔是否正確
		{err=2;}
//		if(document.getElementById("cc").checked){alert("true");};
		switch(err){
			case 0: //正常運作
				ttmp=ttmp+bgc;
			break;
			case 1: //資料庫主從進度不正確
				ttmp=ttmp+"<tr bgcolor=\"#cc00cc\">"
				ste="請檢查主從進度";
				if(document.getElementById("c1").checked){wor=true;}
			break;
			case 2: //資料庫主從檔案錯誤
				ttmp=ttmp+ebgc;
				ste="主從檔案錯誤";
				if(document.getElementById("c2").checked){wor=true;}
			break;
			case 3: //slave 主從標記為"NO"停止中
				ttmp=ttmp+ebgc;
				ste="主從停止！！";
				if(document.getElementById("c3").checked){wor=true;}
			break;
			case 4: //無法連線
				ttmp=ttmp+ebgc;
				ste="無法連結資料庫";
				if(document.getElementById("c4").checked){wor=true;}
			break;

		}
		var cstop=false;
		for(k=0;k<chk2.length;k++){	
			var mm=true;
			switch(k){
				case 4:
					mm=false;
				break;
				case 6:
					cstop=true;
				break;
			}
			if(mm){ttmp=ttmp+"<td>"+chk2[k]+"</td>"};
			if(cstop){k=chk2.length;}

		}
		ttmp=ttmp+"<td>"+chkpos+"</td>"+"<td>"+chk2[8]+"</td>"+"<td>"+ste+"</td>";
	}
	ttmp=ttmp+"</tbody></table>";
	document.getElementById("fishtest").innerHTML=ttmp;
	
	if(wor){
		document.aaa.Play();
	}else{
		document.aaa.Stop();
	}
}
