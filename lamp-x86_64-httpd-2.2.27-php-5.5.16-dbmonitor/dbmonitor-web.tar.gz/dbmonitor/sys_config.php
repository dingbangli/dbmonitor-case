<?php
error_reporting (16);
$db_ip="localhost:/var/lib/mysql/master02/mysql02.sock";
$db_user="ckdb";
$db_pas="db_pas";

$go_user="ckdb";
$go_pas="db_pas";
?>
