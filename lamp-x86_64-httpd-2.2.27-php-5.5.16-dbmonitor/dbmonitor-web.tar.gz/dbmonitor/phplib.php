<?
ini_set('mysql.connect_timeout',5);
function gomysql($ii,$uu,$pp,$dd,$ss)
{
	$link_id=mysql_connect($ii,$uu,$pp); //連結主資料庫
	if($link_id)
	{
		mysql_select_db($dd);
		$back=mysql_query($ss,$link_id);
		mysql_close($link_id);
		return $back;
	}
	else
	{   
		$back[0][0]='error';
	    return $back;
    }
}
?>
