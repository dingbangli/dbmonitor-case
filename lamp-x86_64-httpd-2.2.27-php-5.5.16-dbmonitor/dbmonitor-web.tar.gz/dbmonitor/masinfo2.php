<? 
//   $bb_user="fishgogo";
//   $bb_pas="asdfjkl;qweruiopzxcvm,./";
//   $kk_user="aries";
//   $kk_pas="ay28006@syt";
//   if ($mweb=="bb"){ $musr=$bb_user;$mpas=$bb_pas;}
//   elseif($mweb=="kk"){$musr=$kk_user;$mpas=$kk_pas;}
//   else{$musr=$bb_user;$mpas=$bb_pas;}
$musr="ckdb";
$mpas="ckdb";
$mip=$_GET["mip"];

   $link_id=mysql_connect($mip,$musr,$mpas);
   $str="show full processlist;";
   $str2="show slave status;";
   $result=mysql_query($str,$link_id); //�e�X�d�ߨ��^��Ʈw���A
   $result2=mysql_query($str2,$link_id);
   $vrchkr=mysql_num_rows($result);
   $vrchk=mysql_num_fields($result);
   $vrchk2=mysql_num_fields($result2);
   //$test=mysql_result($result,0,1);
   
   for ($c=0;$c<$vrchkr;$c++)
     {for ($d=0;$d<$vrchk;$d++)
	     {$mshow2[$c][$d]=mysql_result($result,$c,$d);}
		 //$logfile=mysql_result($result,0,'Master_Log_File');
	 }
      for ($e=0;$e<$vrchk2;$e++)
             {$sshow2[0][$e]=mysql_result($result2,0,$e);}
  for ($i=0;$i<$vrchkr;$i++){
   $mshow[$i]=mysql_fetch_array($result);}; 
  for ($j=0;$j<1;$j++){
   $sshow[$j]=mysql_fetch_array($result2);};
?>

<html>
<head>
<title><? echo $mip; ?>Databases processlist</title>
<style type="text/css">
<!--
.style11 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: xx-small; color: #FFFFFF; }
.style12 {color: #FFFFFF}
body {
	background-color: #000000;
}
.style14 {
	font-size: x-large;
	color: #FF0000;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=big5"></head>

<body>
<span class="style12">�@��</span><span class="style14"><? echo $vrchkr;?></span></span><span class="style12">���{�ǰ��椤�I�I</span>
<table border="1" bgcolor="#000000">
 <tr>
    <th nowrap scope="col"><span class="style11">PID</span></th>
    <th nowrap scope="col"><span class="style11">�ϥΪ�</span></th>
    <th nowrap scope="col"><span class="style11">Host</span></th>
    <th nowrap scope="col"><span class="style11">��Ʈw</span></th>
    <th nowrap scope="col"><span class="style11">���O</span></th>
    <th nowrap scope="col"><span class="style11">����ɶ�</span></th>
    <th nowrap scope="col"><span class="style11">���A</span></th>
    <th nowrap scope="col"><span class="style11">�T��</span></th>
  </tr>
<?
 for ($a=0;$a<$vrchkr;$a++) 
 {echo "<tr>";
   for ($b=0;$b<$vrchk;$b++)
   { if($mshow2[$a][$b]==""){ ?><th scope="col">&nbsp;</th><? }
     else {echo "<td>";?> <span class="style11"><? echo $mshow2[$a][$b]; ?><span class="style7"></td> <? }   
   }
 }echo "</tr>";
 ?>
</table>
</p>
<font size=+2 color=ffffff>Show Slave status</font>
</p>
<font size=+2 color=ffffff>Last Error message:<?php echo $sshow2[0][19];?></font>
</p>
<table border="1" bgcolor="#000000">
<?
echo "<tr>";
   for ($b=0;$b<$vrchk2/2;$b++)
   { if($sshow2[0][$b]==""){ ?><th scope="col">&nbsp;</th><? }
     else {echo "<td>";?> <span class="style11"><? echo $sshow2[0][$b]; ?><span class="style7"></td> <? }
   }
echo "</tr>";
echo "<tr>";
   for ($b=($vrchk2/2)+1;$b<$vrchk2;$b++)
   { if($sshow2[0][$b]==""){ ?><th scope="col">&nbsp;</th><? }
     else {echo "<td>";?> <span class="style11"><? echo $sshow2[0][$b]; ?><span class="style7"></td> <? }
   }  
echo "</tr>";

 ?>
</table>

</body>
</html>
