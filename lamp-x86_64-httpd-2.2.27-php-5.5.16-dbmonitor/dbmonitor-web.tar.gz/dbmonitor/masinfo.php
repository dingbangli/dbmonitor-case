<? 
//   $bb_user="fishgogo";
//   $bb_pas="asdfjkl;qweruiopzxcvm,./";
//   $kk_user="aries";
//   $kk_pas="ay28006@syt";
//   if ($mweb=="bb"){ $musr=$bb_user;$mpas=$bb_pas;}
//   elseif($mweb=="kk"){$musr=$kk_user;$mpas=$kk_pas;}
//   else{$musr=$bb_user;$mpas=$bb_pas;}
$musr="ckdb";
$mpas="ckdb";
$mip=$_GET["mip"];
   $link_id=mysql_connect($mip,$musr,$mpas);
   $str="show full processlist;";
   $result=mysql_query($str,$link_id); //�e�X�d�ߨ�^��Ʈw���A
   $vrchkr=mysql_num_rows($result);
   $vrchk=mysql_num_fields($result);
   //$test=mysql_result($result,0,1);
   
   for ($c=0;$c<$vrchkr;$c++)
     {for ($d=0;$d<$vrchk;$d++)
	     {$mshow2[$c][$d]=mysql_result($result,$c,$d);}
		 //$logfile=mysql_result($result,0,'Master_Log_File');
	 }
  for ($i=0;$i<$vrchkr;$i++){
   $mshow[$i]=mysql_fetch_array($result);}; 
?>

<html>
<head>
<title><? echo $mip; ?>Databases processlist</title>
<style type="text/css">
<!--
.style11 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: xx-small; color: #FFFFFF; }
.style12 {color: #FFFFFF}
body {
	background-color: #000000;
}
.style14 {
	font-size: x-large;
	color: #FF0000;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>

<body>
<span class="style12"><? echo $mip;?></span><br>
<span class="style12">共有</span><span class="style14"><? echo $vrchkr;?></span></span><span class="style12">條程序執行中！！</span>
<table border="1" bgcolor="#000000">
 <tr>
    <th nowrap scope="col"><span class="style11">PID</span></th>
    <th nowrap scope="col"><span class="style11">使用者</span></th>
    <th nowrap scope="col"><span class="style11">Host</span></th>
    <th nowrap scope="col"><span class="style11">資料庫</span></th>
    <th nowrap scope="col"><span class="style11">指令</span></th>
    <th nowrap scope="col"><span class="style11">執行時間</span></th>
    <th nowrap scope="col"><span class="style11">狀態</span></th>
    <th nowrap scope="col"><span class="style11">訊息</span></th>
  </tr>
<?
 for ($a=0;$a<$vrchkr;$a++) 
 {echo "<tr>";
   for ($b=0;$b<$vrchk;$b++)
   { if($mshow2[$a][$b]==""){ ?><th scope="col">&nbsp;</th><? }
     else {echo "<td>";?> <span class="style11"><? echo $mshow2[$a][$b]; ?><span class="style7"></td> <? }   
   }
 }echo "</tr>";
 ?>
</table>
</body>
</html>
